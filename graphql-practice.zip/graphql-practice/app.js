const express = require("express");
const { graphqlHTTP } = require('express-graphql');
const { buildSchema } = require('graphql');
const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    database: 'testDB',
    password:"root"
  });
  

const app =express();

const schema = buildSchema(`
type EmployeeDetail {
    id: Int
    name: String
    job:String
    department:String,
    salary:Int,
    hire_date:String
  }

type Result{
    results: [EmployeeDetail]
}

  type Query {
    read: Result
    delete(id:Int!): String
  }

  type Mutation {
    create(input: EmployeeDetail): String
    update(id:Int,input: EmployeeDetail): String
  }
`);

const root = {
    create: ({input}) => {
        connection.query('INSERT INTO employee (id,name,job,department,salary,hire_date) VALUES(?,?,?,?,?,?)',[...Object.values(input)],
        (err,results)=>{
            if(!err)
            return "Insert Record Sucessfully"

            return "Unable to insert record. Internal Server Error" + err.message
        })
    },
    update: ({id,input}) => {
        connection.query('UPDATE users SET ? WHERE id = ?', [{ ...input }, id],(err,res)=>{
            if(!err)
            return "Updated Sucessfully"

            return "Unable to update record. Internal Server error" + err.message
        })
      },
    read: () => {
        connection.query(
            'SELECT * FROM `employee`',
            function(err, results, fields) {
              if(!err)
              return {results};
            }
          );
          
      },
    delete: async ({id}) => {
            connection.query(
                `DELETE FROM employee WHERE id = ${id}`,
                function(err, results, fields) {
                 if(!err)
                 {
                    return "Record deleted successfully"
                 }
                 return "Internal Server Error" + err.message
                }
              );
              
      },

  };  

app.use('/graphql', graphqlHTTP({
    schema: schema,
    rootValue: root,
    graphiql: true,
  }));


app.listen(3000,()=>{
    console.log("Listening on PORT 3000");
})